const fs = require('fs');
const content = fs.readFileSync('/opt/build/repo/LanguageContext.tsx', 'utf8');

const enCode = `  en: {
    nav: {
      home: 'Home',
      about: 'About Us',
      services: 'Services',
      pricing: 'Pricing',
      faq: 'FAQ',
      contact: 'Contacts',
    },
    hero: {
      title: 'Your path to',
      subtitle: 'managed property',
      description: 'We specialize in the management of small and medium segment commercial and private properties, providing transparent and legally correct management',
      contactBtn: 'CONTACT US',
      servicesBtn: 'OUR SERVICES',
    },
    footer: {
      aboutTitle: 'About Us',
      followTitle: 'Follow us',
      contactTitle: 'Contact Information',
      addressLabel: 'Legal address:',
      rights: 'All rights reserved',
      privacy: 'Privacy Policy',
      cookies: 'Cookie Policy',
    },
    about: {
      backBtn: 'Back to Home',
      title: 'About',
      subtitle: 'us',
      highlight: 'Our company provides real estate maintenance and management services in small and medium segment commercial properties, as well as Premium segment private properties. At the same time, we also provide legal management of these properties, which allows property owners to receive both practical property management and professional legal support on property-related issues in one place.',
      p1: 'We work with real estate whose owners value an individual approach, confidentiality, and legally organized relationships with tenants, cooperation partners, and state institutions.',
      p2: 'Although our company is relatively new, we have more than 12 years of practical experience in real estate management. During this time, we have provided daily management of commercial properties, tenant attraction and contract management, as well as coordinated repairs and related development projects. In working with Premium segment private properties, we have provided property management, maintenance planning, and coordination according to clients\\' wishes and needs.',
      p3: 'This experience allows us to look at the property as a functioning system where every well-thought-out and organized decision affects its profitability, value, and long-term profit.',
      p4: 'Our operations are based on a structured approach and individual attitude to each client, with clearly defined tasks and goals already at the beginning of cooperation. We ensure that our clients\\' property is organized, transparently managed, and financially efficient, reducing the owner\\'s daily involvement while ensuring full transparency and control over all processes related to commercial or private property.',
      p5: 'Our work is aimed at long-term cooperation and the organization and development of properties owned by our clients, promoting the preservation of their value and increasing their financial return.',
      imageTaglineLine1: 'Your reliable partner',
      imageTaglineLine2: 'in commercial and private property management',
    },
    benefits: {
      q1: {
        title: 'Who are our services',
        subtitle: 'especially suitable for?',
        items: [
          { title: 'For owners of office buildings, apartment buildings and other commercial objects (small and medium segment)', desc: 'Management of commercial properties, office and mixed-use buildings, and apartment buildings often involves regular communication with tenants, solving technical issues, coordinating service providers, as well as communicating with various state and municipal institutions. We help clients structure these processes and ensure stable and efficient property management.' },
          { title: 'Local and foreign investors with multiple properties', desc: 'Professional management is especially important for investors and entrepreneurs who own several real estate properties or investment objects (commercial objects, rental apartments) in Latvia. Structured management of all properties in one place helps ensure timely resolution of administrative issues, coordinated financial flow, and ensures the preservation and increase of their value in the long term.' },
          { title: 'For owners of detached houses and other private residences', desc: 'Owners of detached houses, villas, summer houses, guest houses, and farmsteads often need a reliable partner to provide regular supervision and administration of the property on their behalf, as well as coordinate necessary works when needed. This is especially true when owners live in another city or outside Latvia, and regular presence in their property is not possible.' }
        ]
      },
      q2: {
        title: 'What ',
        subtitle: 'benefits',
        suffix: ' do clients get',
        suffix2: 'by cooperating with us?',
        desc: 'Cooperation with us ensures a structured, transparent, and responsible approach to real estate management, related legal and administrative issues, and property development. Our goal is to provide clients with an effective set of services on which not only the financial return of the property depends, but also the preservation of its value in the long term.',
        listPrefix: 'By cooperating with us, clients gain several significant advantages:',
        items: [
          { title: 'A comprehensive approach in one place', desc: 'We provide both real estate management and maintenance, as well as legal and corporate support on property-related issues, thus the client does not need to coordinate issues between multiple service providers.' },
          { title: 'Effective cost optimization', desc: 'Clients do not need to hire a separate real estate manager or attract several outsourced service providers for legal, administrative, or organizational issues. Such an approach provides better transparency, predictable costs, and more efficient management of property-related processes.' },
          { title: 'Organization of real estate documentation and legal evaluation', desc: 'If necessary, we also review property documentation, perform legal analysis and risk assessment, which helps identify potential problems and eliminate them in a timely manner. This allows the property owner to make thoughtful decisions and ensure a stable legal basis for further property management and development.' },
          { title: 'One responsible contact person', desc: 'Clients get one contact person who knows all the administrative, legal, and organizational issues related to the specific property, and coordinates all necessary processes in the property.' },
          { title: 'Individual approach and flexible solutions', desc: 'Unlike large real estate companies, we provide an individual approach to each client, working with more complex or non-standard issues that are often not included in classic management services.' },
          { title: 'High professional and confidentiality standards', desc: 'When working with client properties and private information, especially in work with Premium private properties, we adhere to the highest principles of professional ethics, confidentiality, and responsible cooperation.' }
        ]
      }
    },
    services: {
      title: 'Our',
      subtitle: 'Services',
      description: 'We offer both daily real estate maintenance and management, as well as the provision of separate or one-time services according to each client\\'s wishes and needs.',
      learnMore: 'Learn More',
      items: [
        {
                id: 1,
                title: 'Daily administrative management',
                desc: 'This service provides structured and continuous real estate management, allowing the owner to focus on their main business development or investment goals while maintaining transparency over property operations.'
        },
        {
                id: 2,
                title: 'Maintenance budget for technical works',
                desc: 'A pre-established financial fund designed for the prompt resolution of property technical issues and maintenance works. It provides the opportunity to quickly organize necessary works without causing administrative delays.'
        },
        {
                id: 3,
                title: 'Additional services',
                desc: 'Specialized administrative, legal, and project management services that help solve more complex situations or implement property development plans. They are provided together with daily management services or as separate projects according to the client\\'s needs.'
        },
        {
                id: 4,
                title: 'Premium property management',
                desc: 'Individually tailored management for private and high-value properties where particularly careful organization and maintenance are required. The service ensures that the property is professionally managed even when the owner is not residing there.'
        }
      ]
    },
    servicesPage: {
      backBtn: 'Back to Home',
      title: 'Structure of our services',
      subtitle: 'and prices',
      description: 'A professional approach to real estate management – from daily maintenance to legal support.',
      descriptionLabel: 'Service description:',
      learnMore: 'Learn More',
      vatText: 'All service prices indicated above are subject to VAT if provided by the regulatory acts of the Republic of Latvia.',
      items: [
        {
                id: 1,
                title: '1. Daily administrative management',
                intro: 'This is a fixed monthly fee for continuous or regular administrative management of the property. This service is provided for small and medium segment properties and includes:',
                points: [
                        'daily or regular administrative management of real estate',
                        'communication with property tenants and cooperation partners',
                        'attracting tenants or lessees and building sustainable cooperation',
                        'representation in relations with state/municipal institutions and third parties',
                        'organizing necessary technical issues and monitoring their execution',
                        'coordinating maintenance works of the property territory or interior',
                        'coordinating other operational situations on the property by agreement'
                ],
                outro: 'This service provides structured and continuous real estate management, allowing the owner to focus on their main business development or investment goals.',
                costTitle: 'Administrative management service costs',
                costText: 'The daily administrative management fee is determined individually, taking into account the type, size, and management intensity of the property. In practice, the fee for such a service for small segment commercial objects is usually determined starting from 250 € per month, while for medium segment or more complex commercial objects it is agreed upon individually.'
        },
        {
                id: 2,
                title: '2. Maintenance budget for technical works (deposit)',
                intro: \`To ensure fast and efficient resolution of technical issues in the property, a maintenance deposit is used. This is a maintenance budget previously paid by the real estate owner, from which the costs of property technical maintenance works, minor repairs, and other technical issues related to the property are covered.\n\nThis system allows for an immediate response to unforeseen technical issues in the property, maintenance works, or equipment maintenance in the property, without causing delays with additional transfers or separate approvals to resolve them.\n\nThe maintenance budget can be used for:\`,
                points: [
                        'covering the costs of minor or unplanned repair works',
                        'in emergency situations to ensure the safety of people or property',
                        'specialist call-outs in unforeseen or emergency cases',
                        'covering costs for checking technical damage or systems',
                        'covering the costs of territory maintenance works',
                        'purchasing small urgent materials',
                        'covering the costs of other operational maintenance works (this list is not exhaustive and is agreed upon individually in each case)'
                ],
                outro: \`All costs are documented and reflected in a report issued to the owner at pre-agreed times, ensuring full financial transparency. When the deposit balance reaches the set minimum level, the owner is informed about the need to top it up.\n\nSuch a structure ensures operational issue resolution, continuous property maintenance, as well as transparency in the use of budget funds.\`,
                costTitle: 'Amount of the maintenance budget',
                costText: 'The maintenance deposit amount is determined individually, considering the property size, technical condition, and expected volume of maintenance or repair works. In practice, the deposit amount usually starts from 800-1000 €, but for larger properties with more intensive technical maintenance, it can be much larger. A project management or administration fee may be applied for organizing, coordinating, or supervising technical works on the property, which is agreed upon individually in each case.'
        },
        {
                id: 3,
                title: '3. Additional services',
                intro: \`In addition to daily real estate maintenance and management, we also offer clients specialized services needed to resolve more complex situations or for property development. Such services are provided as needed and are organized together with daily services or as separate projects or services.\n\nAdditional services may include:\`,
                points: [
                        'providing legal consultations on lease or tenancy relationship issues',
                        'analysis of legal and financial risks, evaluation of situations, and provision of opinions',
                        'consultations and joint search for investment opportunities for property development',
                        'preparation and administration of lease, tenancy, repair works, and other contracts',
                        'cooperation with an accounting service provider, supervision of financial flow',
                        'in relations with tenants, lessees, state and municipal institutions',
                        'representation for obtaining residence permits in Latvia by investing in real estate',
                        'support in property purchase, sale, or other real estate transactions',
                        'resolution of dispute situations and coordination of debt recovery cases',
                        'corporate support for building sustainable relationships with partners',
                        'attracting necessary specialists or service providers for repair works',
                        'supervision and quality control of repair or reconstruction works',
                        'other legal, organizational, or corporate services by agreement'
                ],
                outro: '',
                costTitle: 'Costs of additional services',
                costText: 'Fees for additional services are usually provided at an hourly rate or as separate projects. The fee for legal services and other consultations is typically set starting from 80 €/hour, but the costs of larger and more labor-intensive projects are agreed upon individually in each case.'
        },
        {
                id: 4,
                title: '4. Premium property management',
                intro: \`In addition to classic property maintenance and management, we also offer clients Premium services for private properties. This service is intended for owners of detached houses, villas, residences, summer houses, country farmsteads, holiday homes, guest houses, and similar real estate.\n\nPremium property management services may include:\`,
                points: [
                        'regular property inspection and management during the owner\\'s absence',
                        'coordination of property territory or interior maintenance works',
                        'representation in relations with state/municipal institutions and third parties',
                        'maintenance of electrical equipment, technical and security systems as needed',
                        'tenant attraction (if necessary) and building sustainable cooperation',
                        'cooperation with cleaners, gardeners, or technical specialists',
                        'property maintenance before or after hosting guests',
                        'preparing the property for the owner\\'s arrival',
                        'providing legal services and business consultations',
                        'other private property management services by agreement'
                ],
                outro: 'Such a service is particularly relevant for those private owners who stay in the property periodically or permanently live outside Latvia. This provides an opportunity to ensure an organized and aesthetic environment, as well as preserve and increase the value of private property in the long term.',
                costTitle: 'Costs of Premium property management',
                costText: 'The fee for Premium property management services is determined individually, considering the property size, location, and required management volume. In practice, the costs of such services usually start from 400 € per month, which is agreed upon individually in each case.'
        }
      ]
    },
    pricingPage: {
      backBtn: 'Back to Home',
      title: 'Cooperation and',
      subtitle: 'costs',
      description: 'The costs of our services are determined individually for each client, considering the type of real estate, size, location, volume, duration, and specifics of services.',
      stepsTitle: 'How does cooperation begin?',
      steps: [
        'Initial consultation remotely (by phone or on ZOOM platform)',
        'Meeting and viewing the real estate in person, assessing the situation',
        'Agreeing on the format of cooperation and preparing an individual offer',
        'Conclusion of the cooperation agreement in person or remotely',
        'Issuing additional power of attorney to perform certain actions (if necessary)',
        'Settlement for the first month of cooperation in advance',
        'Commencement of cooperation'
      ],
      optionsTitle: 'Service',
      optionsSubtitle: 'options',
      modelA: {
        label: 'Model A',
        badge: 'Advantageous',
        title: 'Fixed monthly management fee',
        desc: 'This model includes payment for regular or daily maintenance and management of real estate, with a clearly defined volume of services and duration of cooperation.',
        btn: 'Apply'
      },
      modelB: {
        label: 'Model B',
        title: 'Project or specific task fee',
        desc: 'This model includes payment for the provision of separate or one-time services, or project execution, with a clearly defined volume of work.',
        btn: 'Apply'
      }
    },
    faq: {
      backBtn: 'Back to Home',
      title: 'Frequently Asked',
      subtitle: 'Questions',
      viewAll: 'View all answers',
      items: [
        {
          q: "What types of properties do you work with?",
          a: [
            "Our company provides real estate maintenance and management services in small and medium segment commercial properties, as well as Premium segment private properties. We work with various types of properties, including:",
            "• commercial objects, office buildings, mixed-use buildings, salons, warehouses, and other properties",
            "• apartment buildings, rental apartments, and other investment objects",
            "• country residences, holiday homes, and guest houses",
            "• detached houses, villas, summer houses, and farmsteads"
          ]
        },
        {
          q: "What advantages will clients gain by starting cooperation with you?",
          a: [
            "By cooperating with us, clients gain several significant advantages:",
            { title: "A comprehensive approach in one place", desc: "We provide both real estate management and maintenance, as well as legal and corporate support on property-related issues, thus the client does not need to coordinate issues between multiple service providers." },
            { title: "Effective cost optimization", desc: "Clients do not need to hire a separate real estate manager or attract several outsourced service providers for legal, administrative, or organizational issues. Such an approach provides better transparency, predictable costs, and more efficient management of property-related processes." },
            { title: "Organization of real estate documentation and legal evaluation", desc: "If necessary, we also review property documentation, perform legal analysis and risk assessment, which helps identify potential problems and eliminate them in a timely manner. This allows the property owner to make thoughtful decisions and ensure a stable legal basis for further property management and development." },
            { title: "One responsible contact person", desc: "Clients get one contact person who knows all the administrative, legal, and organizational issues related to the specific property, and coordinates all necessary processes in the property." },
            { title: "Individual approach and flexible solutions", desc: "Unlike large real estate companies, we provide an individual approach to each client, working with more complex or non-standard issues that are often not included in classic management services." },
            { title: "High professional and confidentiality standards", desc: "When working with client properties and private information, especially in work with Premium private properties, we adhere to the highest principles of professional ethics, confidentiality, and responsible cooperation." }
          ]
        },
        {
          q: "How is client data processing and confidentiality ensured?",
          a: "All commercial and private information about the property, its owner, and tenants is processed in compliance with high professional standards and confidentiality. Information identifying our clients can only be disclosed in cases specified by the regulatory acts of the Republic of Latvia or upon receiving client consent."
        },
        {
          q: "In which regions of Latvia do you work?",
          a: "We are a young company and currently work mainly in Riga, Riga district, Jurmala, and Saulkrasti. In the near future, we also plan to expand to Sigulda and Cesis. However, we are open to evaluating cooperation opportunities in other regions by individual agreement."
        }
      ]
    },
    process: {
      title: "Cooperation",
      subtitle: "process",
      desc: "To ensure effective and transparent cooperation, preparation for it takes place in several stages:",
      items: [
        { title: "Initial free consultation (remote)", desc: "At this stage, the real estate situation is discussed, issues to be resolved are identified, and the owner\\'s wishes and plans are heard." },
        { title: "Initial familiarization with the object", desc: "At this stage, a physical inspection of the property is carried out, and an initial discussion of technical and legal issues is held to clarify their possible solutions." },
        { title: "Preparation of a service plan", desc: "Based on the results of the negotiations, an individual property management plan and a cooperation model with the services chosen by the client are prepared." },
        { title: "Start of management", desc: "After the approval of the property management plan and the conclusion of the cooperation agreement, property maintenance and management begins." }
      ]
    },
    cookieBanner: {
      title: "This site uses cookies",
      description: "We use our own and third-party cookies to ensure and improve the operation of the website, adapt information about our products and services, as well as analyze site traffic. By checking 'Customize choice', you can make your choice. By clicking 'Accept all', you agree to the use of all cookies. Closing the cookie window with 'X' does not activate cookies. Read more about the Cookie Policy and Privacy Policy in the bottom corner of the page.",
      policyLink: "",
      acceptBtn: "Accept all",
      rejectBtn: "Reject",
      settingsBtn: "Customize choice"
    },
    contact: {
      backBtn: 'Back to Home',
      title: 'Your reliable partner',
      subtitle: 'in commercial and private property management',
      formTitle: 'Contact us',
      formSubtitle: 'to sign up for a consultation',
      formBoxTitle: 'Apply for a consultation',
      labelName: 'Name, Surname *',
      labelCompany: 'Company',
      labelEmail: 'Email *',
      labelPhone: 'Phone *',
      labelMessage: 'Message / Property description',
      consentText: 'I have read and agree to the',
      privacyLink: 'data processing terms',
      submitBtn: 'Submit application',
      submitting: 'Submitting...',
      successTitle: 'Thank you, your message has been received',
      successSubtitle: '',
      successMessage: 'We will contact you shortly.',
      newRequestBtn: 'Send new application',
      infoTitle: 'Contact',
      infoSubtitle: 'information',
      callUs: 'Call us',
      writeUs: 'Write to us',
      contactBtn: 'Contact',
    }
  }`;

const lines = content.split(/\r?\n/);
// Update type Language = 'lv' | 'ru';
const typeIndex = lines.findIndex(l => l.includes("export type Language = 'lv' | 'ru';"));
if (typeIndex > -1) {
    lines[typeIndex] = "export type Language = 'lv' | 'ru' | 'en';";
}

const ruStartIndex = lines.findIndex(l => l.includes('ru: {'));
if (ruStartIndex > -1) {
  const newContent = [...lines.slice(0, ruStartIndex), enCode + ',', ...lines.slice(ruStartIndex)].join('\n');
  fs.writeFileSync('/opt/build/repo/LanguageContext.tsx', newContent);
  console.log('Successfully injected en translation!');
} else {
  console.log('ru: { not found!');
}
