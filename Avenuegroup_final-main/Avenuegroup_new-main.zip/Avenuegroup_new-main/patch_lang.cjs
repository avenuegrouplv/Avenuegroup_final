const fs = require('fs');

let content = fs.readFileSync('LanguageContext.tsx', 'utf8');

// Point 1: Replace process items in LV
content = content.replace(/process: \{\s*title: "Sadarbības",\s*subtitle: "process",\s*desc: "Lai nodrošinātu efektīvu un pārskatāmu sadarbību, sagatavošanās tai notiek vairākos posmos:",\s*items: \[\s*\{ title: "Sākotnējā bezmaksas konsultācija \(telefoniski vai video formātā\)", desc: "Šajā posmā tiek pārrunāta nekustamā īpašuma situācija, identificēti risināmie jautājumi un uzklausītas īpašnieka vēlmes" \},\s*\{ title: "Objekta apskate un sākotnējā izvērtēšana", desc: "Šajā posmā notiek īpašuma apskate dabā un veikta sākotnējā tehnisko un juridisko jautājumu apspriešana, lai noskaidrotu to risinājumu iespējas un iespējamās sadarbības modeli" \},\s*\{ title: "Pakalpojumu plāna sagatavošana", desc: "Šajā posmā, pamatojoties uz notikušo sarunu rezultātiem, tiek sagatavots individuāls īpašuma pārvaldības plāns, un sadarbības modelis ar klienta izvēlētajiem pakalpojumiem" \},\s*\{ title: "Pārvaldības uzsākšana", desc: "Pēc īpašuma pārvaldības plāna apstiprināšanas un sadarbības līguma noslēgšanas, tiek uzsākta īpašuma pārvaldība" \}\s*\]\s*\}/, 
`process: {
      title: "Sadarbības",
      subtitle: "process",
      desc: "Lai nodrošinātu efektīvu un pārskatāmu sadarbību, sagatavošanās tai notiek vairākos posmos:",
      items: [
        { title: "Sākotnējā bezmaksas konsultācija (telefoniski vai video)", desc: "Šajā posmā tiek pārrunāta nekustamā īpašuma situācija, identificēti risināmie jautājumi un uzklausītas īpašnieka vēlmes un ieceres" },
        { title: "Sākotnējā iepazīšanās ar objektu", desc: "Šajā posmā notiek īpašuma apskate dabā un veikta sākotnējā tehnisko un juridisko jautājumu apspriešana, lai noskaidrotu to iespējamos risinājumus" },
        { title: "Pakalpojumu plāna sagatavošana", desc: "Šajā posmā, pamatojoties uz sarunu rezultātiem, tiek sagatavots individuāls īpašuma pārvaldības plāns, un sadarbības modelis ar klienta izvēlētajiem pakalpojumiem" },
        { title: "Pārvaldības uzsākšana", desc: "Pēc īpašuma pārvaldības plāna apstiprināšanas un sadarbības līguma noslēgšanas, tiek uzsākta īpašuma apsaimniekošana un pārvaldība" }
      ]
    }`);

// Point 1: Replace process items in RU
content = content.replace(/process: \{\s*title: "Процесс",\s*subtitle: "сотрудничества",\s*desc: "Для обеспечения эффективного и прозрачного сотрудничества, подготовка к нему проходит в несколько этапов:",\s*items: \[\s*\{ title: "Первоначальная бесплатная консультация \(по телефону или в видео формате\)", desc: "На этом этапе обсуждается ситуация с недвижимостью, выявляются вопросы для решения и выслушиваются пожелания владельца" \},\s*\{ title: "Осмотр объекта и первоначальная оценка", desc: "На этом этапе происходит осмотр недвижимости в натуре и первоначальное обсуждение технических и юридических вопросов для выяснения возможностей их решения и возможной модели сотрудничества" \},\s*\{ title: "Подготовка плана услуг", desc: "На этом этапе, основываясь на результатах проведенных переговоров, подготавливается индивидуальный план управления недвижимостью и модель сотрудничества с выбранными клиентом услугами" \},\s*\{ title: "Начало управления", desc: "После утверждения плана управления недвижимостью и заключения договора о сотрудничестве, начинается управление недвижимостью" \}\s*\]\s*\}/, 
`process: {
      title: "Процесс",
      subtitle: "сотрудничества",
      desc: "Для обеспечения эффективного и прозрачного сотрудничества, подготовка к нему проходит в несколько этапов:",
      items: [
        { title: "Первоначальная бесплатная консультация (по телефону или видео)", desc: "На этом этапе обсуждается ситуация с недвижимостью, выявляются вопросы для решения и выслушиваются пожелания и замыслы владельца." },
        { title: "Первоначальное ознакомление с объектом", desc: "На этом этапе происходит осмотр недвижимости в натуре и первоначальное обсуждение технических и юридических вопросов для выяснения их возможных решений." },
        { title: "Подготовка плана услуг", desc: "На этом этапе, основываясь на результатах переговоров, подготавливается индивидуальный план управления недвижимостью и модель сотрудничества с выбранными клиентом услугами." },
        { title: "Начало управления", desc: "После утверждения плана управления недвижимостью и заключения договора о сотрудничестве, начинается обслуживание и управление недвижимостью." }
      ]
    }`);

// Point 2: Benefits Section modification
content = content.replace(
  `q2: {
        title: 'Kādas priekšrocības iegūst klienti',
        subtitle: '',
        suffix: ', uzsākot sadarbību ar mums?',`,
  `q2: {
        title: 'Kādas ',
        subtitle: 'priekšrocības',
        suffix: ' iegūst klienti,',
        suffix2: 'uzsākot sadarbību ar mums?',`
);

content = content.replace(
  `q2: {
        title: 'Какие преимущества получают клиенты',
        subtitle: '',
        suffix: ', начиная сотрудничество с нами?',`,
  `q2: {
        title: 'Какие ',
        subtitle: 'преимущества',
        suffix: ' получают клиенты,',
        suffix2: 'начиная сотрудничество с нами?',`
);

// Point 3: About image tagline split into two variables
content = content.replace(
  `imageTagline: 'Jūsu uzticamais partneris komercīpašumu un privātīpašumu pārvaldībā',`,
  `imageTaglineLine1: 'Jūsu uzticamais partneris',
      imageTaglineLine2: 'komercīpašumu un privātīpašumu pārvaldībā',`
);
content = content.replace(
  `imageTagline: 'Ваш надежный партнер в управлении коммерческой и частной недвижимостью',`,
  `imageTaglineLine1: 'Ваш надежный партнер',
      imageTaglineLine2: 'в управлении коммерческой и частной недвижимостью',`
);

fs.writeFileSync('LanguageContext.tsx', content, 'utf8');
