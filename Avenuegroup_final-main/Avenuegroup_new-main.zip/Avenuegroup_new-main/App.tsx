// Avenue Group Application
import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { AvenueBenefits } from './components/AvenueBenefits';
import { Services } from './components/Services';
import { ServicesPage } from './components/ServicesPage';
import { FAQPage } from './components/FAQPage';
import { ContactPage } from './components/ContactPage';
import { PrivacyPolicyPage } from './components/PrivacyPolicyPage';
import { CookiePolicyPage } from './components/CookiePolicyPage';
import { UsefulInfoPage } from './components/UsefulInfoPage';
import { Footer } from './components/Footer';
import { CookieBanner } from './components/CookieBanner';
import { LanguageProvider } from './LanguageContext';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const Home: React.FC = () => {
  return (
    <>
      <Hero />
      <About />
      <AvenueBenefits />
      <Services />
      <FAQPage isPreview={true} />
      <ContactPage isEmbedded={true} />
    </>
  );
};

const AppContent: React.FC = () => {
  const location = useLocation();
  const isSpecialPage = ['/Privatums', '/Sikdatnes', '/Par-mums', '/Pakalpojumi', '/BUJ', '/Kontakti', '/Noderigi'].includes(location.pathname);

  return (
    <div id="top" className="min-h-screen selection:bg-zinc-700 selection:text-white bg-[#0a0a0a]">
      <Header />
      <main className={isSpecialPage ? 'pt-24' : ''}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Sakums" element={<Home />} />
          <Route path="/Par-mums" element={<About isStandalone={true} />} />
          <Route path="/Pakalpojumi" element={<ServicesPage />} />
          <Route path="/BUJ" element={<FAQPage />} />
          <Route path="/Kontakti" element={<ContactPage />} />
          <Route path="/Privatums" element={<PrivacyPolicyPage />} />
          <Route path="/Sikdatnes" element={<CookiePolicyPage />} />
          <Route path="/Noderigi" element={<UsefulInfoPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <Router>
        <ScrollToTop />
        <AppContent />
      </Router>
    </LanguageProvider>
  );
};

export default App;