import React from 'react';
import { ArrowLeft, Lightbulb } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import { useNavigate } from 'react-router-dom';

export const UsefulInfoPage: React.FC = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();

  return (
    <div className="bg-black min-h-screen pt-12 pb-24 text-gray-300">
      <div className="container mx-auto px-6 max-w-4xl">
        <button
          onClick={() => navigate('/')}
          className="flex items-center text-yellow-400 font-bold tracking-widest text-xs mb-12 hover:text-white transition-colors font-sans"
        >
          <ArrowLeft size={18} className="mr-2" /> {t('useful.backBtn')}
        </button>

        <div className="mb-16">
          <div className="flex items-center space-x-4 text-yellow-400 mb-6">
            <Lightbulb size={48} />
            <h1 className="text-lg md:text-2xl font-black italic tracking-tighter leading-none">
              {t('useful.title')}
            </h1>
          </div>
        </div>

        <div className="space-y-12 leading-relaxed text-base">
          <section className="space-y-6">
            <p>
              Šī sadaļa drīzumā tiks papildināta ar noderīgu informāciju par nekustamo īpašumu apsaimniekošanu un juridisko pārvaldību.
            </p>
          </section>
        </div>
        
        <div className="mt-12 pt-12 border-t border-white/10 flex justify-center">
          <button
            onClick={() => navigate('/')}
            className="bg-yellow-400 text-black px-8 py-3 font-bold hover:bg-white transition-colors"
          >
            {t('useful.closeBtn')}
          </button>
        </div>
      </div>
    </div>
  );
};
